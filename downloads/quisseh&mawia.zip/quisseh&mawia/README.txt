quisseh&mawia ~ 2014-10-07 ~ by quisseh

a pure platform game about love, new beginnings, and gastrointestinal
discomfort.

this game must be run in a Windows environment (XP or above). beyond that, it
has no dependencies besides what is contained within this folder. the exe file
must remain within this folder for the game to run successfully. please make
a shortcut if you would like to launch the game from a different location.

to get started, simply double-click the "quisseh&mawia" executable file.

controls:
   -move -> arrow keys
   -jump -> z, x, space, up arrow key
   -pause -> enter, p
   -quit -> esc

enjoy! :)

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

questions/comments/suggestions?
   - contact me: contact@quisseh.net
   - visit me: http://quisseh.net/

copyright 2014 quisseh. all rights reserved.

this software is freeware and distributed as is, without warranty or
condition of any kind. quisseh is not liable for any damages whatsoever.

be nice.
