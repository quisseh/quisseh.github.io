LvR ~ 2017-12-27 ~ by quisseh

a two-player minigame compilation for the Game Boy Advance.

two ways to play:
   - load ROM onto a flash cart and play on GBA/GBP/DS
   - run ROM in a GBA emulator (mGBA recommended)

controls:
   - L -> move player 1 (blue) in levels; move cursor up in menus
   - R -> move player 2 (red) in levels; move cursor down in menus
   - START -> proceed with selected menu option

enjoy!

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

questions/comments/suggestions?
   - contact me: contact@quisseh.net
   - visit me: http://quisseh.net

copyright 2017 quisseh. all rights reserved.

this software is freeware and distributed as is, without warranty or
condition of any kind. quisseh is not liable for any damages whatsoever.
