mawia goes to school! ~ 2014-07-04 ~ by quisseh

a top-down exploration game with an agenda; a proposal in disguise.
experience a not-so-average day in the life of a schoolteacher, mawia.

this game must be run in a Windows environment (XP or above). beyond that, it
has no dependencies besides what is contained within this folder. the exe file
must remain within this folder for the game to run successfully. please make
a shortcut if you would like to launch the game from a different location.

to get started, simply double-click the "mawia goes to school!" executable
file.

controls:
   -move -> arrow keys
   -pause -> enter
   -quit -> esc

enjoy! :)

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

questions/comments/suggestions?
   - contact me: contact@quisseh.net
   - visit me: http://quisseh.net/

copyright 2014 quisseh. all rights reserved.

this software is freeware and distributed as is, without warranty or
condition of any kind. quisseh is not liable for any damages whatsoever.

be nice.
