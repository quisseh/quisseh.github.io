clipq ~ 2014-04-26 ~ by quisseh

clipq is a simple and intuitive clipboard manager. it remembers the things
that you copy.

clipq must run in a Windows environment (XP or above). it also requires that
Java 7 (or above) is installed on your PC. the latest version of Java
can be downloaded at http://java.com/download/.

to get started, simply double-click the "clipq" executable file.

enjoy! :)

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

*user manual*

start by copying things
   - things can be plain text, hyperlinks, or images
   - ctrl+c or right-click->copy

copied things will appear in your clipq queue
   - plain text things will appear black with a green border
   - hyperlink things will appear blue with a purple border
   - image things will appear with a red border

highlight any thing to assign it to your clipboard
   - highlight by single-clicking, scrolling with the keypad, or searching
   - when you paste, you will paste the highlighted thing
      - ctrl+v or right-click->paste

searching
   - you can search for plain text or hyperlink things by searching
   - while clipq has focus, just start typing text. things that contain the
     text you type will be selected

double-click or press enter on any thing to auto-paste it
   - clipq will return you to the previous window and paste the thing for you

shift+click hyperlink things to open them in your default web browser

click the quit button in clipq to be prompted to quit
   - upon clicking the ok button, you will permanently lose all of the things
     you copied

click the delete button in clipq or press the delete key to delete any
highlighted thing

click the about button in clipq to view information about clipq
   - click the manual button to view this manual in your default web browser

click the x button in clipq to hide clipq in your system tray
   - clipq will continue to capture all of the things you copy while hidden
   - right-click the clipq icon in your system tray to show/hide, quit, or
     view information about clipq

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

questions/comments/suggestions?
   - contact me: contact@quisseh.net
   - visit me: http://quisseh.net/

copyright 2014 quisseh. all rights reserved.

this software is freeware and distributed as is, without warranty or
condition of any kind. quisseh is not liable for any damages whatsoever.

be nice.
